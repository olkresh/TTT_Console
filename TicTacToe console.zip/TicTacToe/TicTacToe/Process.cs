﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static System.Console;

//create a list of winning combinations
//every time it goes through it, make it assign 


namespace TicTacToe
{
    class Process
    {
        Random rnd = new Random();
        BotPlayer botPlayer = new BotPlayer();

        public void RunKeyMenu(int usersNum)
        {
            //define settings for the selectable menu
            string prompt = "You can select cells of the menu by keyboard arrows and press enter to put your symbol";
            string placeO = "place";

            string[,] grid = {
                { "-", "-", "-" },
                { "-", "-", "-" },
                { "-", "-", "-" }
            };

            MenuClass mainMenu = new MenuClass(prompt, grid, placeO);

            int won = 0;

            //go further according to the number of users selected
            switch (usersNum)
            {
                case 0:
                    //zero players
                    //this is just a fun thing so I did not try to make it efficient

                    int j = 0;
                    int speed = 0;
                    int counter = 1;
                    for (int k = 1; k <= 40;k+=1)
                    {
                        counter++;
                        j += k * 7;
                        speed = 5 + 7500 / (j * j);
                        if (k < 4)
                        {
                            counter += k;
                        }
                        else if (k > 3 && k < 8)
                        {
                            counter += k * k;
                        }
                        else if (k >= 8)
                        {
                            counter += k * j;
                        }
                        else if (k > 12)
                        {
                            counter += j/60 * j;
                        }
                        else if (k > 14)
                        {
                            counter += j * j;
                        }

                        RunTwoBots(speed, counter);   
                    }

                    ForegroundColor = ConsoleColor.Green;
                    BackgroundColor = ConsoleColor.Black;

                    Console.Clear();
                    for (int i = 01; i < 100; i+=10)
                    {
                        

                        PrintMap();
                        Thread.Sleep((i));
                        Console.Clear();
                        Thread.Sleep((750/(i * i)));
                    }

                    for (int i = 100;  i > 01; i-=1)
                    {
                        Console.Clear();
                        ForegroundColor = ConsoleColor.Green;
                        BackgroundColor = ConsoleColor.Black;
                        PrintMap();
                        ForegroundColor = ConsoleColor.Black;
                        BackgroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Rockets' launch in {i} miliseconds");
                        Thread.Sleep(50);
                        Console.ResetColor();

                    }

                    Console.Clear();

                    //PrintMap();


                    Console.WriteLine("\n\n\n\n                           4534 Nuclear Missiles were launched");
                    Console.WriteLine("\n\n\n\n                           Destination: 51651.3213213");

                    Thread.Sleep((5250));
                    Console.Clear();
                    //Console.WriteLine("press enter to play again; space to menu");
                    //Console.WriteLine("press space to exit");

                    ConsoleKey keyPressed;
                    ConsoleKeyInfo keyInfo = Console.ReadKey();
                    keyPressed = keyInfo.Key;
                    if (keyPressed == ConsoleKey.Enter)
                    {
                        RunKeyMenu(0);
                    }
                    break;
                case 1:
                    //bot vs human

                    int turnNumber = 0;
                    while (won != 1)
                    {
                        //human's turn
                        mainMenu.DisplayOptions("x");
                        placeXorO("x");
                        checkIfFull();
                        if (won == 1)
                        {
                            break;
                        }
                        
                        //bot's turn: bring the grid and return it
                        var grid2 = botPlayer.BotTurn(grid, "o", turnNumber);
                        grid = grid2;
                        checkIfWon("o");
                        turnNumber++;
                    }

                    Console.WriteLine("game is over");
                    Console.WriteLine("press enter to play again; space to menu");

                    //ask if play again
                    ConsoleKeyInfo keyInfo2 = Console.ReadKey();
                    keyPressed = keyInfo2.Key;
                    if (keyPressed == ConsoleKey.Enter)
                    {
                        RunKeyMenu(1);
                    }
                    break;
                case 2:
                    while (won != 1)
                    {
                        //x's turn
                        mainMenu.DisplayOptions("x");
                        placeXorO("x");
                        checkIfFull();
                        if (won == 1)
                        {
                            break;
                        }

                        //o's turn
                        placeXorO("o");
                    }
                    Console.WriteLine("press enter to play again; space to menu");
                    
                    //ask if to play again
                    ConsoleKeyInfo keyInfo3 = Console.ReadKey();
                    keyPressed = keyInfo3.Key;
                    if (keyPressed == ConsoleKey.Enter)
                    {
                        RunKeyMenu(2);
                    }
                    break;
            }

            //defined the human input
            void placeXorO(string XorO)
            {
                while (true)
                {
                    //check if the spot is empty
                    int[] indx = mainMenu.Run(XorO);
                    if (grid[indx[0], indx[1]] == "-")
                    {
                        grid[indx[0], indx[1]] = XorO;
                        break;
                    }
                    else
                    {
                        Console.WriteLine("spot is taken, try again");
                        Thread.Sleep(1500);
                    }
                }
                checkIfWon(XorO);
            }

            void checkIfWon(string XorO)
            {
                //this methods calculates if ther are any things in a row
                int diagL = 0;
                int diagR = 0;
                for (int i = 0; i < 3; i++)
                {
                    int horSum = 0;
                    int verSum = 0;

                    //check/print diagonal win
                    if (grid[i, i] == XorO) { 
                        diagL++;
                        
                        if (diagL == 3)
                        {
                            printWinnerGrid(XorO, [0, 0, 1, 1, 2, 2]);
                            //printWinnerGrid(XorO, [0, 0, 1, 1, 2, 2]);
                            won = 1;
                        }
                    }

                    //check/print diagonal win
                    if (grid[i, 2-i] == XorO) {  
                        diagR++;

                        if (diagR == 3)
                        {
                            printWinnerGrid(XorO, [0, 2, 1, 1, 2, 0]);
                            won = 1;
                        }
                    }

                    for (int y = 0; y < 3; y++)
                    {
                        if (grid[y, i] == XorO) {  
                            verSum++;

                            if (verSum == 3)
                            {
                                printWinnerGrid(XorO, [0, i, 1, i, 2, i]);
                                Console.ReadKey();
                                won = 1;
                            }
                        }

                        if (grid[i, y] == XorO) {  
                            horSum++;

                            if (horSum == 3)
                            {
                                printWinnerGrid(XorO, [i, 0, i, 1, i, 2]);
                                won = 1;
                            }
                        }

                        if (horSum == 4)
                        {
                            Console.Clear();
                            mainMenu.DisplayOptions($"nothing.");

                            Console.WriteLine($"{XorO} won!");
                            won = 1;
                        }


                    }

                }
            }

            void checkIfFull()
            { 
                //checks if there are more than 5 "x" on the grid
                if (won  == 0)
                {
                    int fullSum = 0;
                    for (int i = 0; i < 3; i++)
                    {
                        for (int y = 0; y < 3; y++)
                        {
                            if (grid[i, y] == "x")
                            { fullSum++; }
                        }
                    }
                    if (fullSum == 5)
                    {
                        Console.Clear();
                        mainMenu.DisplayOptions("nothing. grid is full.");
                        Console.WriteLine("its a draw.");
                        won = 1;
                    }
                }
                
            }

            void printWinnerGrid(string XorO, int[] win)
            {
                Thread.Sleep(400);

                Console.Clear ();
                //showcase the winner in green
                for (int i = 0; i < 30; i++) {

                    int waitTime = 0;

                Console.Clear();
                Console.WriteLine(prompt);
                Console.WriteLine("place nothing");

                for (int l = 0; l < 3; l++)
                {
                    for (int k = 0; k < 3; k++)
                    {
                        string currentOption = grid[l, k];
                        if ((l == win[0] && k == win[1]) || 
                            (l == win[2] && k == win[3]) || 
                            (l == win[4] && k == win[5]))
                        {
                                if (i > 4) {
                                    ForegroundColor = ConsoleColor.Green;
                                }
                                else
                                {
                                    waitTime = 70;
                                    if (i%2 == 0)
                                    {
                                        ForegroundColor = ConsoleColor.White;
                                    }
                                    else
                                    {
                                        ForegroundColor = ConsoleColor.Green;
                                    }
                                }

                            }
                        else
                        {
                            ForegroundColor = ConsoleColor.White;
                        }


                        Console.Write($" {currentOption} ");

                        ForegroundColor = ConsoleColor.White;
                        BackgroundColor = ConsoleColor.Black;
                    }
                    Console.WriteLine();
                }

                ResetColor();
                Console.WriteLine($"{XorO} won!");

                Thread.Sleep( waitTime );
                }
            }
        }

        public void PrintMap()
        {
            //a method just for the fun part
            string map = @"
░░░░░░░░░░░░░░░░░░░░░░░░████  ░░  ████▓▓░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░  ░░██▓▓██▒▒████████████░░░░░░░░▒▒██░░░░░░░░  ░░░░░░░░░░██  ░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░██  ░░    ▒▒░░  ▓▓██████████░░░░░░░░██░░░░░░░░░░░░  ░░░░░░░░  ██  ░░              ░░░░
░░░░░░░░░░░░▓▓  ████  ▒▒██░░░░▓▓████████░░░░░░░░░░░░░░░░░░░░  ░░▒▒▒▒▓▓██████████              ░░░░
  ████████████▓▓▓▓░░██▓▓  ██░░░░██████  ░░░░░░░░░░████▒▒  ██░░██▒▒▓▓████████████            ░░██  
░░██████████████████▓▓██  ▒▒░░░░████░░░░░░░░░░████████▓▓████████████████████████▓▓██████████████░░
░░██░░░░████████████  ░░▒▒████░░░░░░░░░░░░  ░░  ░░██████████████████████████████████░░░░      ░░░░
  ░░░░░░  ▓▓██████████████████░░░░░░░░░░░░▓▓████████████████████████████████████████▒▒░░░░░░░░░░░░
░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░  ▓▓████████▓▓████████████████████████████  ░░░░░░░░░░░░
░░░░░░░░░░░░██████████████▓▓░░░░░░░░░░░░░░  ████▒▒██    ██  ██████████████████████▓▓██  ░░░░░░░░░░
░░░░░░░░░░░░██████████████░░░░░░░░░░░░░░░░░░██░░░░  ▓▓████  ████████████████████    ██░░░░░░░░░░░░
░░░░░░░░░░░░░░▒▒██████▓▓░░░░░░░░░░░░░░░░░░██████████████████████████████████████░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░  ▓▓██  ▒▒▒▒  ░░░░░░░░░░░░▒▒████████████░░████▒▒  ██████▓▓██████  ░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░  ████░░  ██░░░░░░░░░░░░▓▓████████████▓▓██████░░░░████░░████░░░░░░░░░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░██  ▓▓  ░░░░░░░░░░  ████████████████░░░░░░░░██░░░░░░  ░░░░██░░░░░░░░░░  ░░░░
░░░░░░░░░░░░░░░░░░░░░░░░████████░░░░░░░░░░  ░░  ██████████░░░░░░░░░░░░░░  ▒▒  ░░    ░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░  ██████████░░░░░░░░░░░░░░████████░░░░░░░░░░░░░░░░░░▒▒    ░░░░██░░  ░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░████████████░░░░░░░░░░░░████████      ░░░░░░░░░░░░░░░░░░▒▒░░░░▒▒░░  ░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░██████████░░░░░░░░░░░░████████░░  ░░░░░░░░░░░░░░░░░░░░▓▓██░░░░░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░▒▒████████░░░░░░░░░░░░██████░░██░░  ░░░░░░░░░░░░░░░░██████████░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░  ████░░░░░░░░░░░░░░░░▒▒██▓▓░░░░░░░░░░░░░░░░░░░░░░░░██████████░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░████▒▒░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  ░░░░████░░░░░░░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░██░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  ░░░░▓▓░░░░
░░░░░░░░░░░░░░░░░░░░░░░░░░██░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
";

            Console.WriteLine(map);
        }
        public void RunTwoBots(int speed, int counter)
        {
            //defines how two players will play with each other with a predesigned pause which is accelerating
            string prompt = "Playing game with two bots.";
            string placeO = "Turn of ";
            string[,] options2d = {
                { "-", "-", "-" },
                { "-", "-", "-" },
                { "-", "-", "-" }
            };

            BotPlayer botPlayer = new BotPlayer();
            MenuClass mainMenu = new MenuClass(prompt, options2d, placeO);

            int timeWait = speed;
            int i = 0;

            while ( i <= 5) {
                counter++;

                //display options
                Console.Clear();
                printGrid(options2d, counter);
                Thread.Sleep(timeWait);
                string[,] gridNew;

                Console.Clear();

                //make the bot go on a random corner for the first move
                if (i == 0)
                {
                    gridNew = botPlayer.BotTurn(options2d, "r", 10);
                }
                else
                {
                    gridNew = botPlayer.BotTurn(options2d, "x", 10);
                }


                printGrid(gridNew, counter);
                options2d = gridNew;

                Thread.Sleep(timeWait);
                i++;

                //breaks when the grid is full
                if (i == 5)
                {
                    break;
                }

                var gridNew2 = botPlayer.BotTurn(options2d, "o", i);
                options2d = gridNew2;
            }

            void printGrid(string[,] Options2d, int gameNumber)
            {
                //just a fun thing all values are made up

                Console.Write("    Users: ");
                ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("ZERO");
                ForegroundColor = ConsoleColor.White;

                Console.Write("    Number of games: ");
                ForegroundColor = ConsoleColor.Green;
                Console.WriteLine($"{gameNumber}\n");

                ForegroundColor = ConsoleColor.White;
                Console.Write("    Seed: ");
                ForegroundColor = ConsoleColor.Green;
                var rndA = rnd.Next(100000000, 900000000);
                Console.WriteLine($"{rndA}\n");

                for (int i = 0; i < 3; i++)
                {
                    //string currentOption = Options[i];
                    string prefix;

                    Console.Write("    ");

                    for (int y = 0; y < 3; y++)
                    {
                        string currentOption = Options2d[i, y];
                        
                        prefix = " ";
                        ForegroundColor = ConsoleColor.Black;
                        BackgroundColor = ConsoleColor.White;

                        Console.Write($"{prefix}{currentOption} ");
                    }
                    ResetColor();
                    Console.WriteLine("");
                }
            }
        }
    }
}
