﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    internal class Archive
    {
        /*
        if (whoseTurn == "o_second" && turnOrderNum == 10)
            {
                whoseTurn = "o";
                turnOpp = "x";

                //check if bot almost won
                ifAlmostLostWon(whoseTurn, whoseTurn);

                //check if "x" almost won
                ifAlmostLostWon(turnOpp, whoseTurn);


                //if the center is taken
                if (grid[1, 1] == turnOpp)
                {
                    //trying middle left/right side
                    if (spotEmpty)
                    {
                        if (grid[2, 2] == "-")
                        {
                            grid[2, 2] = whoseTurn;
                            spotEmpty = false;
                        }
                    }
                }
                else
                {
                    //check if corners are empty and then go to the opposite corner of o
                    int ifCornersEmpty = 0;

                    //check if corners are empty
                    for (int i = 0; i < 2; i += 2)
                    {
                        if (grid[i * 2, 0] == turnOpp)
                        {
                            ifCornersEmpty++;
                        }

                        if (grid[i * 2, 2] == turnOpp)
                        {
                            ifCornersEmpty++;
                        }
                    }



                    if (ifCornersEmpty == 0 && spotEmpty && turnOrderNum == 100)
                    {
                        //check if corners are taken by o
                        if (grid[2, 1] == turnOpp && spotEmpty)
                        {
                            for (int i = 0; i < 2; i += 1)
                            {
                                int y = (i - 1) * 2;
                                int d = y > 0 ? y : -y;
                                int z = i * 2;

                                if (grid[i * 2, 0] == whoseTurn)
                                {
                                    grid[d, 0] = whoseTurn;
                                    spotEmpty = false;
                                }

                                if (grid[i * 2, 2] == whoseTurn)
                                {
                                    grid[d, 2] = whoseTurn;
                                    spotEmpty = false;
                                }
                            }
                        }
                        else { 

                        for (int i = 0; i < 2; i += 1)
                        {
                            if (grid[i * 2, 0] == whoseTurn)
                            {
                                if (grid[i * 2, 2] == "-")
                                {
                                    grid[i * 2, 2] = whoseTurn;
                                    spotEmpty = false;
                                }
                            }

                            if (grid[i * 2, 2] == whoseTurn)
                            {
                                if (grid[i * 2, 0] == "-")
                                {
                                    grid[i * 2, 0] = whoseTurn;
                                    spotEmpty = false;
                                }
                            }
                        }
                        }

                        /*
                        if (grid[1,2] == turnOpp && grid[2,1] == turnOpp && spotEmpty)
                        {
                            grid[0,2]  = whoseTurn;
                            spotEmpty = false;
                        }
                        else
                        {

                        }
                        
                        for (int k = 0; (k < 2); k++)
                        {
                            int y = (k - 1) * 2;
                            int d = y > 0 ? y : -y;
                            int z = k * 2;


                            if (grid[k * 2, 1] == turnOpp && spotEmpty)
                            {
                                grid[z, 0] = whoseTurn;
                                spotEmpty = false;
                            }
                            if (grid[1, k * 2] == turnOpp && spotEmpty)
                            {
                                grid[0, z] = whoseTurn;
                                spotEmpty = false;
                            }
                            
                        }

                        
    }
                    else if (ifCornersEmpty == 1 && spotEmpty && turnOrderNum == 100)
                    {
                        //put opposite to o
                        for (int i = 0; i< 2; i += 1)
                        {
                            if (grid[i * 2, 0] == whoseTurn)
                            {
                                if (grid[i * 2, 2] == "-")
                                {
                                    grid[i * 2, 2] = whoseTurn;
                                    spotEmpty = false;
                                }
                            }

                            if (grid[i * 2, 2] == whoseTurn)
{
    if (grid[i * 2, 0] == "-")
    {
        grid[i * 2, 0] = whoseTurn;
        spotEmpty = false;
    }
}
                        }
                    }
                }

            }

        */
        /*
                for (int i = 0; i < 3; i++)
                {
                    XorO = "x";
                    XorOpp = "o";
                    int horSum = 0;
                    int verSumBot = 0;

                    if (options2d[i, i] == XorO) { diagL++; }
                    if (options2d[i, 2 - i] == XorO) { diagR++; }

                    for (int j = 0; j < 3; j++)
                    {
                        if (options2d[j, i] == XorO) { verSumBot++; }
                        if (options2d[i, j] == XorO) { horSum++; }

                        if (verSumBot == 2 && spotEmpty)
                        {
                            //Console.WriteLine($"x almost won vertically on column {i}");
                            Thread.Sleep(500);
                            if (options2d[j, i] == "-")
                            {
                                options2d[j, i] = XorOpp;
                                Console.WriteLine("found open spot");
                                //Thread.Sleep(500);
                                spotEmpty = false;
                                
                                break;
                            }
                            else
                            {
                                //Console.WriteLine("spot is taken, so ill try the other one");
                                //Thread.Sleep(500);
                            }
                        }

                        if (horSum == 2 && spotEmpty)
                        {
                            //Console.WriteLine($"x almost won vertically on column {j}");
                            //Thread.Sleep(500);
                            if (options2d[i, j] == "-")
                            {
                                options2d[i, j] = XorOpp;
                                Console.WriteLine("found open spot");
                                //Thread.Sleep(500);
                                spotEmpty = false;
                                
                                break;
                            }
                        }
                    }

                    if (spotEmpty)
                    {
                        if (diagL == 2)
                        {
                            Console.WriteLine($"x almost won diagonally");
                            //Thread.Sleep(500);

                            for (int k = 0; k < 3; k++)
                            {
                                if (options2d[k, k] == "-")
                                {
                                    options2d[k, k] = "o";
                                    Console.WriteLine("found open spot");
                                    //Thread.Sleep(500);
                                    spotEmpty = false;
                                    
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("spot is taken, so ill try the other one");
                                    //Thread.Sleep(500);
                                }
                            }
                        }

                        if (diagR == 2)
                        {
                            Console.WriteLine($"x almost won diagonally");
                            //Thread.Sleep(500);

                            for (int k = 0; k < 3; k++)
                            {
                                if (options2d[k, 2 - k] == "-")
                                {
                                    options2d[k, 2 - k] = "o";
                                    Console.WriteLine("found open spot");
                                    //Thread.Sleep(500);
                                    spotEmpty = false;
                                    
                                    break;
                                }
                                else
                                {
                                    Console.WriteLine("spot is taken, so ill try the other one");
                                    //Thread.Sleep(500);
                                }
                            }
                        }
                    }



                }

                */
    }
}
