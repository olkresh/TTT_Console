﻿using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Linq;
using TicTacToe;



Process process = new Process();


void StartA()
{
    //Title = "Amortization";
    RunMainMenuA();
    //process.RunKeyMenu(0);
}

void RunMainMenuA()
{

    string prompt = "Hello! \nThis is TicTacToe. You can switch options of the menu by keyboard arrows and select with enter";
    string[] options = { "[0] Zero Players", "[1] One player", "[2] Two players", "[-] Exit" };
    MainMenu mainMenu = new MainMenu(prompt, options);
    mainMenu.DisplayOptions();

    int selectedIndex = mainMenu.Run();

    if (selectedIndex == 3)
    {
        Environment.Exit(0);
    }
    else
    {
        process.RunKeyMenu(selectedIndex);
    }


}


while (true)
{
    StartA();
}
