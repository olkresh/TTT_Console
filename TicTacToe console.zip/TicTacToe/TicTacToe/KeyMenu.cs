﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace TicTacToe
{
    class MenuClass
    {
        private int SelectedIndex;
        private int[] SelectedIndex2d;

        private string[,] Grid;
        private string Prompt;
        private string WhoseTurn;

        public MenuClass(string prompt, string[,] grid, string whoseTurn)
        {
            this.Prompt = prompt;
            WhoseTurn = whoseTurn;
            this.Grid = grid;
            SelectedIndex2d = [ 0, 0 ];

        }

        public void DisplayOptions(string XorO)
        {

            Console.WriteLine(Prompt);
            Console.WriteLine(WhoseTurn + " " + XorO);

            for (int i = 0; i < 3; i++)
            {
                //string currentOption = Options[i];
                string prefix;

                for (int y = 0; y < 3; y++)
                {
                    string currentOption = Grid[i, y];
                    if (i == SelectedIndex2d[0] && y == SelectedIndex2d[1])
                    {
                        prefix = " ";
                        ForegroundColor = ConsoleColor.Black;
                        BackgroundColor = ConsoleColor.White;
                    }
                    else
                    {
                        prefix = " ";

                        ForegroundColor = ConsoleColor.White;
                        BackgroundColor = ConsoleColor.Black;
                    }

                    Console.Write($"{prefix}{currentOption} ");
                }
                Console.WriteLine();
            }

            ResetColor();
        }

        public int[] Run(string XorO)
        {
            ConsoleKey keyPressed;
            do
            {
                Clear();
                DisplayOptions(XorO);

                ConsoleKeyInfo keyInfo = Console.ReadKey();
                keyPressed = keyInfo.Key;

                if (keyPressed == ConsoleKey.UpArrow)
                {
                    SelectedIndex2d[0]--;
                    if (SelectedIndex2d[0] == -1)
                    {
                        SelectedIndex2d[0] = 2;
                    }
                }
                else if (keyPressed == ConsoleKey.DownArrow)
                {
                    SelectedIndex2d[0]++;
                    if (SelectedIndex2d[0] == 3)
                    {
                        SelectedIndex2d[0] = 0;
                    }
                }
                else if (keyPressed == ConsoleKey.RightArrow)
                {
                    SelectedIndex2d[1]++;
                    if (SelectedIndex2d[1] == 3)
                    {
                        SelectedIndex2d[1] = 0;
                    }
                }
                else if (keyPressed == ConsoleKey.LeftArrow)
                {
                    SelectedIndex2d[1]--;
                    if (SelectedIndex2d[1] == -1)
                    {
                        SelectedIndex2d[1] = 2;
                    }
                }
            } while (keyPressed != ConsoleKey.Enter);

            return SelectedIndex2d;
        }
    }
}
