﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicTacToe
{
    public class BotPlayer
    {
        public string[,] BotTurn(string[,] grid, string whoseTurn, int turnOrderNum)
        {
            //1. see if there are any almost won situations
            //3. if the spot is busy, then check for other almost won cases

            //recognize if the first is in the side and put the opposite to it

            //Whose Turn - selection of bot's role
            string turnOpp;

            Random rnd = new Random();
            bool spotEmpty = true;


            if (whoseTurn == "o")
            {
                turnOpp = "x";
            }
            else
            {
                turnOpp = "o";
            }

            if (whoseTurn == "r")
            {
                whoseTurn = "o";
                turnOpp = "x";
            }

            //check if either of users almost won
            void ifAlmostLostWon(string scan, string actor)
            {
                if (spotEmpty)
                {
                    int diagL = 0;
                    int diagR = 0;

                    //scan - X or O which will be scanned and checked for
                    //actor - the thing that will be putted

                    for (int i = 0; i < 3; i++)
                    {
                        //track diagonnal paths
                        if (grid[i, i] == scan) { diagL++; }
                        if (grid[i, 2 - i] == scan) { diagR++; }

                        //track and play horizontal paths
                        int horSum = 0;
                        int verSum = 0;
                        for (int j = 0; j < 3; j++)
                        {
                            if (diagR == 2 && spotEmpty)
                            {
                                ////Console.WriteLine($"x almost won diagonally");
                                //Thread.Sleep(500);

                                if (grid[j, 2 - j] == "-")
                                {
                                    grid[j, 2 - j] = actor;
                                    //Console.WriteLine("found open spot");
                                    //Thread.Sleep(500);
                                    spotEmpty = false;
                                    break;
                                }
                            }
                            if (diagL == 2 && spotEmpty)
                            {
                                ////Console.WriteLine($"x almost won diagonally");
                                //Thread.Sleep(500);

                                if (grid[j, j] == "-")
                                {
                                    grid[j, j] = actor;
                                    //Console.WriteLine("found open spot");
                                    //Thread.Sleep(500);
                                    spotEmpty = false;
                                    break;
                                }
                            }

                            if (grid[j, i] == scan) { verSum++; }
                            if (grid[i, j] == scan) { horSum++; }

                            if (verSum == 2 && spotEmpty)
                            {
                                //Console.WriteLine($"x almost won vertically on column {i}");
                                for (int k = 0; k < 3; k++)
                                {
                                    if (grid[k, i] == "-")
                                    {
                                        grid[k, i] = actor;
                                        //Console.WriteLine("found open spot");
                                        spotEmpty = false;
                                        break;
                                    }
                                    //else { //Console.WriteLine("did found open spot so ill try the other cells on"); }
                                }
                            }

                            if (horSum == 2 && spotEmpty)
                            {
                                //Console.WriteLine($"x almost won horizontally on row {i}");
                                //Thread.Sleep(1500);
                                for (int k = 0; k < 3; k++)
                                {
                                    if (grid[i, k] == "-")
                                    {
                                        grid[i, k] = actor;
                                        //Console.WriteLine("found open spot");
                                        spotEmpty = false;
                                        break;
                                    }
                                    //else { //Console.WriteLine("did found open spot so ill try the other cells on"); }
                                }
                            }
                        }
                    }
                }

            }

            void tryCorners()
            {
                //trying corners
                if (spotEmpty)
                {
                    for (int i = 0; i < 3; i += 2)
                    {
                        if (grid[i, 0] == "-" && spotEmpty)
                        {
                            grid[i, 0] = whoseTurn;
                            spotEmpty = false;
                            //mark that someome went to break the loop and block others from going
                        }

                        if (grid[i, 2] == "-" && spotEmpty)
                        {
                            grid[i, 2] = whoseTurn;
                            spotEmpty = false;
                            //mark that someome went to break the loop and block others from going
                        }
                    }
                }
            }

            if (whoseTurn == "o_first" || turnOrderNum == 0)
            {
                whoseTurn = "o";
                turnOpp = "x";

                //if the center is taken
                if (grid[1,1] == turnOpp)
                {
                    //trying middle left/right side
                    if (spotEmpty)
                    {
                        if (grid[2, 0] == "-")
                        {
                            grid[2, 0] = whoseTurn;
                            spotEmpty = false;
                        }
                    }
                }

                //if any middle spots are taken
                //and put the thing oppositely
                for (int k = 0; (k < 2); k++)
                {
                    int X = (k - 1) * 2;
                    int d = X > 0 ? X : -X;
                    if (grid[k * 2, 1] == turnOpp)
                    {

                        grid[k * 2, 2] = whoseTurn;
                        spotEmpty = false;
                    }
                    if (grid[1, k * 2] == turnOpp && spotEmpty)
                    {
                        grid[2, k * 2] = whoseTurn;
                        spotEmpty = false;
                    }
                }

                //middleOpposite();
            }

            //new code
            if (grid[1, 1] == "x" && grid[0,2] == "x" && turnOrderNum == 1)
            {
                grid[0, 0] = "o";
                spotEmpty = false;
            }

            //on the third move, check if there's two middles and one corner. if yes, then go in the corner

            if (turnOrderNum == 2)
            {
                int ifCornersEmpty = 0;
                int middleSideTaken = 0;

                ifAlmostLostWon(whoseTurn, whoseTurn);
                ifAlmostLostWon(turnOpp, whoseTurn);

                

                //check if corners are empty
                for (int i = 0; i < 2; i += 2)
                {
                    if (grid[i * 2, 0] == turnOpp)
                    {
                        ifCornersEmpty++;
                    }

                    if (grid[i * 2, 2] == turnOpp)
                    {
                        ifCornersEmpty++;
                    }
                }

                for (int k = 0; (k < 2); k++)
                {
                    if (grid[k * 2, 1] == turnOpp)
                    {
                        middleSideTaken++;
                    }
                    if (grid[1, k * 2] == turnOpp && spotEmpty)
                    {
                        middleSideTaken++;
                    }

                }

                if (ifCornersEmpty == 1 && middleSideTaken == 2)
                {
                    tryCorners();
                }
            }


            while (spotEmpty)
            {
                if (whoseTurn == "r0")
                {
                    whoseTurn = "x";
                    turnOpp = "o";

                    int h = rnd.Next(0, 2)*2;
                    int v = rnd.Next(0, 2)*2;

                    ////Console.WriteLine("acting on random");
                    //Thread.Sleep(1500);


                    if (grid[h, v] == "-")
                    {
                        grid[h, v] = whoseTurn;

                        spotEmpty = false;
                        break;
                    }
                }

                if (whoseTurn == "r")
                {
                    whoseTurn = "x";
                    turnOpp = "o";

                    int h = rnd.Next(0, 3);
                    int v = rnd.Next(0, 3);

                    if (grid[h, v] == "-")
                    {
                        grid[h, v] = whoseTurn;

                        spotEmpty = false;
                        break;
                    }
                }

                if (whoseTurn == "ro")
                {
                    whoseTurn = "o";
                    turnOpp = "x";

                    

                    ////Console.WriteLine("acting on random");
                    //Thread.Sleep(1500);

                    while (spotEmpty)
                    {
                        int h = rnd.Next(0, 3);
                        int v = rnd.Next(0, 3);

                        if (grid[h, v] == "-")
                        {
                            grid[h, v] = whoseTurn;

                            spotEmpty = false;
                            break;
                        }

                        //Console.WriteLine("randomizer didn't work");
                        //Thread.Sleep(500);
                    }
                    
                }



                //check if bot almost won
                ifAlmostLostWon(whoseTurn, whoseTurn);

                //check if "x" almost won
                ifAlmostLostWon(turnOpp, whoseTurn);

                //trying the center piece
                if (grid[1, 1] == "-" && spotEmpty)
                {
                    grid[1, 1] = whoseTurn;
                    spotEmpty = false;
                }

                //trying middle left/right side
                if (spotEmpty)
                {
                    if (grid[2, 1] == "-")
                    {
                        grid[2, 1] = whoseTurn;
                        break;
                    }
                }

                if (spotEmpty)
                {
                    if (grid[1, 0] == "-")
                    {
                        grid[1, 0] = whoseTurn;
                        break;
                    }
                }

                tryCorners();

                



                



                //try random
                if (spotEmpty)
                {
                    int x = rnd.Next(0, 3);
                    int y = rnd.Next(0, 3);

                    ////Console.WriteLine("acting on random");
                    //Thread.Sleep(1500);


                    if (grid[x, y] == "-")
                    {
                        grid[x, y] = whoseTurn;
                        
                        spotEmpty = false;
                        break;
                    }
                }
            }
        
            return grid;

        }

    }
}

